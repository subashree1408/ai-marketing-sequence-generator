"""AI Marketing Sequence Generator: Streamlit college project."""
import csv
import io
import json
import os

import streamlit as st
from dotenv import load_dotenv
from generator import ai_sequence, demo_sequence

load_dotenv()
st.set_page_config(page_title="AI Marketing Sequence Generator", page_icon="📣", layout="centered")
st.title("📣 AI Marketing Sequence Generator")
st.caption("Plan a multi-step marketing campaign for email, WhatsApp, or social media.")

# Streamlit Cloud secrets are optional. Avoid requiring a secrets.toml file.
try:
    cloud_key = st.secrets.get("OPENAI_API_KEY", "")
    cloud_model = st.secrets.get("OPENAI_MODEL", "")
except (FileNotFoundError, KeyError):
    cloud_key, cloud_model = "", ""
api_key = cloud_key or os.getenv("OPENAI_API_KEY", "")
model = cloud_model or os.getenv("OPENAI_MODEL", "gpt-4o-mini")

with st.form("campaign_form"):
    product = st.text_input("Product or service name *", placeholder="e.g., GlowUp Skincare")
    audience = st.text_input("Target audience *", placeholder="e.g., College students aged 18–25")
    goal = st.selectbox("Campaign goal", ["Brand awareness", "Lead generation", "Product launch", "Customer engagement", "Sales conversion"])
    platform = st.selectbox("Marketing platform", ["Email", "WhatsApp", "Instagram", "LinkedIn", "SMS"])
    tone = st.selectbox("Writing tone", ["Friendly", "Professional", "Exciting", "Informative", "Persuasive"])
    count = st.slider("Number of messages", min_value=2, max_value=5, value=3)
    mode = st.radio("Generation mode", ["Demo (free, no API key)", "AI (OpenAI API key required)"])
    submitted = st.form_submit_button("✨ Generate sequence", use_container_width=True)

if submitted:
    if not product.strip() or not audience.strip():
        st.error("Please enter both the product name and target audience.")
    elif mode.startswith("AI") and not api_key:
        st.error("AI mode requires OPENAI_API_KEY. Add it in .env locally or Streamlit Cloud secrets.")
    else:
        with st.spinner("Creating your campaign..."):
            try:
                if mode.startswith("AI"):
                    result = ai_sequence(product.strip(), audience.strip(), goal, platform, tone, count, api_key, model)
                    st.session_state["generation_type"] = "AI-generated"
                else:
                    result = demo_sequence(product.strip(), audience.strip(), goal, platform, tone, count)
                    st.session_state["generation_type"] = "Template demo (not AI-generated)"
                st.session_state["campaign"] = result
                st.session_state["platform"] = platform
            except Exception as exc:
                st.session_state.pop("campaign", None)
                st.error(f"Generation failed: {exc}")

if "campaign" in st.session_state:
    campaign = st.session_state["campaign"]
    st.divider()
    st.subheader("Your marketing sequence")
    st.info(st.session_state["generation_type"] + " • " + st.session_state["platform"])
    for index, item in enumerate(campaign, start=1):
        with st.container(border=True):
            st.markdown(f"**Message {index} — Day {item['day']}**")
            st.markdown(f"**Subject / Hook:** {item['subject']}")
            st.write(item["message"])
            st.markdown(f"**Call to action:** {item['call_to_action']}")
    st.download_button(
        "⬇️ Download JSON", json.dumps(campaign, indent=2, ensure_ascii=False),
        file_name="marketing_sequence.json", mime="application/json", use_container_width=True,
    )
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=["day", "subject", "message", "call_to_action"])
    writer.writeheader()
    writer.writerows(campaign)
    st.download_button(
        "⬇️ Download CSV", output.getvalue(), file_name="marketing_sequence.csv",
        mime="text/csv", use_container_width=True,
    )

st.caption("Review all AI-generated content for accuracy, consent, and applicable marketing rules before use. This app creates drafts; it does not send messages.")
