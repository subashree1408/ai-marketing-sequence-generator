"""Campaign generation functions for the Streamlit application."""
import json
import os
from openai import OpenAI


def demo_sequence(product, audience, goal, platform, tone, count):
    """Generate a clearly labeled, offline sample sequence (not AI-generated)."""
    templates = [
        ("Meet {product}", "Introducing {product}! Made for {audience}. Discover how it fits your needs."),
        ("Why {product}?", "Looking for a better solution? Explore the benefits of {product} and see what makes it worth considering."),
        ("Explore the details", "Curious about {product}? Take a closer look and decide whether it is right for you."),
        ("Questions? We've got answers", "Have questions about {product}? Reach out and learn more before making a decision."),
        ("Ready to get started?", "If {product} sounds right for you, take the next step today."),
    ]
    messages = []
    for i in range(count):
        subject, body = templates[i % len(templates)]
        messages.append({
            "day": 1 + i * 2,
            "subject": subject.format(product=product),
            "message": body.format(product=product, audience=audience),
            "call_to_action": "Learn more",
        })
    return messages


def ai_sequence(product, audience, goal, platform, tone, count, api_key, model):
    """Call OpenAI and validate structured campaign content."""
    client = OpenAI(api_key=api_key)
    system = (
        "You are a responsible marketing copywriter. Return ONLY a valid JSON object "
        "with a 'messages' array. Each item must have: day (positive integer), "
        "subject (string), message (string), call_to_action (string). "
        "Create distinct, useful messages, with increasing days. "
        "Avoid fabricated testimonials, false urgency, unsupported claims, and spammy language. "
        "Do not invent prices, discounts, or links. Keep messages concise and platform appropriate."
    )
    user = (
        f"Product/service: {product}\nAudience: {audience}\nGoal: {goal}\n"
        f"Platform: {platform}\nTone: {tone}\nNumber of messages: {count}\n"
        "Schedule messages on distinct days starting with day 1."
    )
    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
        response_format={"type": "json_object"},
        temperature=0.7,
    )
    raw = response.choices[0].message.content
    data = json.loads(raw or "{}")
    items = data.get("messages")
    if not isinstance(items, list) or len(items) != count:
        raise ValueError("AI response did not contain the requested number of messages. Try again.")
    cleaned = []
    for item in items:
        if not isinstance(item, dict):
            raise ValueError("Invalid AI message format.")
        day = int(item["day"])
        subject = str(item["subject"]).strip()
        message = str(item["message"]).strip()
        cta = str(item["call_to_action"]).strip()
        if day < 1 or not all((subject, message, cta)):
            raise ValueError("AI returned an incomplete message.")
        cleaned.append({"day": day, "subject": subject, "message": message, "call_to_action": cta})
    if sorted(m["day"] for m in cleaned) != sorted(set(m["day"] for m in cleaned)):
        raise ValueError("AI returned duplicate campaign days. Try again.")
    return sorted(cleaned, key=lambda m: m["day"])
